package com.clarkcraft;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.BlockPosArgumentType;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.util.List;

/**
 * /clarkcraft  (أو /كرت)
 *   zone create <اسم> <نوع_الكرت> <من> <إلى>
 *   zone around <اسم> <نوع_الكرت> <نصف_القطر>   (حول مكانك، من أسفل لأعلى العالم)
 *   zone remove <اسم>
 *   zone list
 *   give <لاعب> <منطقة>     (يعطيه الكرت ويسمح له بالدخول)
 *   revoke <لاعب> <منطقة>   (يسحب الإذن)
 */
public final class ZoneCommands {
	private static final SuggestionProvider<ServerCommandSource> CARD_TYPES =
			(ctx, builder) -> CommandSource.suggestMatching(List.of("pharaoh", "roman", "golden"), builder);
	private static final SuggestionProvider<ServerCommandSource> ZONES =
			(ctx, builder) -> CommandSource.suggestMatching(
					ZoneManager.data.zones.stream().map(z -> z.name).toList(), builder);

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			dispatcher.register(root("clarkcraft"));
			dispatcher.register(root("كرت"));
		});
	}

	private static LiteralArgumentBuilder<ServerCommandSource> root(String name) {
		return CommandManager.literal(name)
				.requires(ZoneManager::isAdmin)
				.then(CommandManager.literal("zone")
						.then(CommandManager.literal("create")
								.then(CommandManager.argument("name", StringArgumentType.word())
										.then(CommandManager.argument("card", StringArgumentType.word()).suggests(CARD_TYPES)
												.then(CommandManager.argument("from", BlockPosArgumentType.blockPos())
														.then(CommandManager.argument("to", BlockPosArgumentType.blockPos())
																.executes(ZoneCommands::create))))))
						.then(CommandManager.literal("around")
								.then(CommandManager.argument("name", StringArgumentType.word())
										.then(CommandManager.argument("card", StringArgumentType.word()).suggests(CARD_TYPES)
												.then(CommandManager.argument("radius", IntegerArgumentType.integer(1, 500))
														.executes(ZoneCommands::around)))))
						.then(CommandManager.literal("remove")
								.then(CommandManager.argument("name", StringArgumentType.word()).suggests(ZONES)
										.executes(ZoneCommands::remove)))
						.then(CommandManager.literal("list").executes(ZoneCommands::list)))
				.then(CommandManager.literal("give")
						.then(CommandManager.argument("player", EntityArgumentType.player())
								.then(CommandManager.argument("zone", StringArgumentType.word()).suggests(ZONES)
										.executes(ZoneCommands::give))))
				.then(CommandManager.literal("revoke")
						.then(CommandManager.argument("player", EntityArgumentType.player())
								.then(CommandManager.argument("zone", StringArgumentType.word()).suggests(ZONES)
										.executes(ZoneCommands::revoke))));
	}

	private static int create(CommandContext<ServerCommandSource> ctx) {
		BlockPos a = BlockPosArgumentType.getBlockPos(ctx, "from");
		BlockPos b = BlockPosArgumentType.getBlockPos(ctx, "to");
		return add(ctx, StringArgumentType.getString(ctx, "name"), StringArgumentType.getString(ctx, "card"),
				Math.min(a.getX(), b.getX()), Math.min(a.getY(), b.getY()), Math.min(a.getZ(), b.getZ()),
				Math.max(a.getX(), b.getX()), Math.max(a.getY(), b.getY()), Math.max(a.getZ(), b.getZ()));
	}

	private static int around(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
		ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
		int r = IntegerArgumentType.getInteger(ctx, "radius");
		BlockPos c = p.getBlockPos();
		return add(ctx, StringArgumentType.getString(ctx, "name"), StringArgumentType.getString(ctx, "card"),
				c.getX() - r, -64, c.getZ() - r, c.getX() + r, 320, c.getZ() + r);
	}

	private static int add(CommandContext<ServerCommandSource> ctx, String name, String card,
						   int x1, int y1, int z1, int x2, int y2, int z2) {
		if (ModItems.byName(card) == null) {
			ctx.getSource().sendError(Text.literal("نوع الكرت غير صحيح. الأنواع: pharaoh, roman, golden"));
			return 0;
		}
		if (ZoneManager.find(name) != null) {
			ctx.getSource().sendError(Text.literal("يوجد منطقة بهذا الاسم مسبقاً."));
			return 0;
		}
		ZoneManager.Zone zone = new ZoneManager.Zone();
		zone.name = name;
		zone.card = card;
		zone.dimension = ctx.getSource().getWorld().getRegistryKey().getValue().toString();
		zone.x1 = x1; zone.y1 = y1; zone.z1 = z1;
		zone.x2 = x2; zone.y2 = y2; zone.z2 = z2;
		ZoneManager.data.zones.add(zone);
		ZoneManager.save();
		ctx.getSource().sendFeedback(() -> Text.literal("✔ تم إنشاء المنطقة المحظورة: " + name), true);
		return 1;
	}

	private static int remove(CommandContext<ServerCommandSource> ctx) {
		String name = StringArgumentType.getString(ctx, "name");
		boolean removed = ZoneManager.data.zones.removeIf(z -> z.name.equalsIgnoreCase(name));
		ZoneManager.save();
		if (!removed) {
			ctx.getSource().sendError(Text.literal("المنطقة غير موجودة."));
			return 0;
		}
		ctx.getSource().sendFeedback(() -> Text.literal("✔ تم حذف المنطقة: " + name), true);
		return 1;
	}

	private static int list(CommandContext<ServerCommandSource> ctx) {
		if (ZoneManager.data.zones.isEmpty()) {
			ctx.getSource().sendFeedback(() -> Text.literal("لا توجد مناطق محظورة."), false);
			return 0;
		}
		for (ZoneManager.Zone z : ZoneManager.data.zones) {
			ctx.getSource().sendFeedback(() -> Text.literal("• " + z.name + " | كرت: " + z.card
					+ " | مسموح لهم: " + z.allowed.size()
					+ " | (" + z.x1 + "," + z.z1 + ") → (" + z.x2 + "," + z.z2 + ")"), false);
		}
		return ZoneManager.data.zones.size();
	}

	private static int give(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
		ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
		ZoneManager.Zone zone = ZoneManager.find(StringArgumentType.getString(ctx, "zone"));
		if (zone == null) {
			ctx.getSource().sendError(Text.literal("المنطقة غير موجودة."));
			return 0;
		}
		Item card = ModItems.byName(zone.card);
		zone.allowed.add(target.getUuidAsString());
		ZoneManager.save();
		target.getInventory().offerOrDrop(new ItemStack(card));
		target.sendMessage(Text.literal("§a✔ حصلت على كرت وصلاحية دخول: " + zone.name), false);
		ctx.getSource().sendFeedback(() -> Text.literal("✔ تم السماح للاعب بدخول " + zone.name), true);
		return 1;
	}

	private static int revoke(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
		ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
		ZoneManager.Zone zone = ZoneManager.find(StringArgumentType.getString(ctx, "zone"));
		if (zone == null) {
			ctx.getSource().sendError(Text.literal("المنطقة غير موجودة."));
			return 0;
		}
		zone.allowed.remove(target.getUuidAsString());
		ZoneManager.save();
		ctx.getSource().sendFeedback(() -> Text.literal("✔ تم سحب الصلاحية من اللاعب."), true);
		return 1;
	}

	private ZoneCommands() {
	}
}
