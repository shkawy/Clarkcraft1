package com.clarkcraft;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class ModItemGroup {
	public static void init() {
		ItemGroup group = FabricItemGroup.builder()
				.icon(() -> new ItemStack(ModItems.PHARAOH_CARD))
				.displayName(Text.translatable("itemGroup.clarkcraft.main"))
				.entries((context, entries) -> {
					ModItems.CARDS.forEach(entries::add);
					ModBlocks.ITEMS.forEach(entries::add);
				})
				.build();
		Registry.register(Registries.ITEM_GROUP,
				RegistryKey.of(RegistryKeys.ITEM_GROUP, Identifier.of(ClarkCraft.MOD_ID, "main")), group);
	}

	private ModItemGroup() {
	}
}
