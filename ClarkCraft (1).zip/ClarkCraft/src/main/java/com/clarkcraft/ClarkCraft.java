package com.clarkcraft;

import net.fabricmc.api.ModInitializer;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.biome.Biome;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClarkCraft implements ModInitializer {
	public static final String MOD_ID = "clarkcraft";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static final RegistryKey<Biome> PHARAOH_DESERT = biome("pharaoh_desert");
	public static final RegistryKey<Biome> PALM_OASIS = biome("palm_oasis");
	public static final RegistryKey<Biome> ROMAN_PLAINS = biome("roman_plains");
	public static final RegistryKey<Biome> OLIVE_GROVE = biome("olive_grove");

	private static RegistryKey<Biome> biome(String path) {
		return RegistryKey.of(RegistryKeys.BIOME, Identifier.of(MOD_ID, path));
	}

	@Override
	public void onInitialize() {
		ModBlocks.init();
		ModItems.init();
		ModItemGroup.init();

		ModWorldgen.init();

		ZoneManager.load();
		ZoneCommands.register();
		ZoneGuard.register();
		LOGGER.info("ClarkCraft جاهز!");
	}
}
