package com.clarkcraft;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.PlacedFeature;

/** يضيف أشجار الزيتون والنخيل لبايومات ماينكرافت العادية. */
public final class ModWorldgen {
	private static RegistryKey<PlacedFeature> feature(String path) {
		return RegistryKey.of(RegistryKeys.PLACED_FEATURE, Identifier.of(ClarkCraft.MOD_ID, path));
	}

	public static void init() {
		BiomeModifications.addFeature(
				BiomeSelectors.includeByKey(BiomeKeys.PLAINS, BiomeKeys.FOREST, BiomeKeys.SAVANNA),
				GenerationStep.Feature.VEGETAL_DECORATION, feature("olive_trees_few"));
		BiomeModifications.addFeature(
				BiomeSelectors.includeByKey(BiomeKeys.DESERT, BiomeKeys.BEACH),
				GenerationStep.Feature.VEGETAL_DECORATION, feature("palm_trees_few"));
	}

	private ModWorldgen() {
	}
}
