package com.clarkcraft;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.command.ServerCommandSource;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** يخزّن المناطق المحظورة والمسموح لهم في config/clarkcraft.json */
public final class ZoneManager {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	public static class Zone {
		public String name;
		public String dimension;
		public String card; // pharaoh | roman | golden
		public int x1, y1, z1, x2, y2, z2;
		public Set<String> allowed = new HashSet<>(); // UUIDs

		public boolean contains(String dim, double x, double y, double z) {
			return dimension.equals(dim)
					&& x >= x1 && x < x2 + 1
					&& y >= y1 && y < y2 + 1
					&& z >= z1 && z < z2 + 1;
		}
	}

	public static class Data {
		public List<String> admins = new ArrayList<>(); // أسماء اللاعبين الذين يتحكمون بالمود
		public List<Zone> zones = new ArrayList<>();
	}

	public static Data data = new Data();

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("clarkcraft.json");
	}

	public static void load() {
		try {
			if (Files.exists(file())) {
				Data loaded = GSON.fromJson(Files.readString(file()), Data.class);
				if (loaded != null) {
					data = loaded;
				}
			} else {
				save();
			}
		} catch (Exception e) {
			ClarkCraft.LOGGER.error("تعذّر قراءة clarkcraft.json", e);
		}
	}

	public static void save() {
		try {
			Files.writeString(file(), GSON.toJson(data));
		} catch (IOException e) {
			ClarkCraft.LOGGER.error("تعذّر حفظ clarkcraft.json", e);
		}
	}

	public static Zone find(String name) {
		for (Zone z : data.zones) {
			if (z.name.equalsIgnoreCase(name)) {
				return z;
			}
		}
		return null;
	}

	public static boolean isAdminName(String name) {
		for (String a : data.admins) {
			if (a.equalsIgnoreCase(name)) {
				return true;
			}
		}
		return false;
	}

	/** الكونسول، أو اللاعبون المكتوبة أسماؤهم في admins، أو أي أحد في العالم الفردي. */
	public static boolean isAdmin(ServerCommandSource source) {
		if (source.getEntity() == null) {
			return true;
		}
		if (source.getServer().isSingleplayer()) {
			return true;
		}
		return isAdminName(source.getName());
	}

	private ZoneManager() {
	}
}
